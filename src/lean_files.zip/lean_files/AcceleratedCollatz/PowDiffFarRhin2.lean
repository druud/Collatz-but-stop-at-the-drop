-- SPDX-License-Identifier: MIT
import AcceleratedCollatz.PowDiffFarRhin1

/-!
# The upper walk to 10^200, stretch 2 of 4

The kernel checks the upper fraction of every node from `farNode200_1` to `farNode200_2`, at
K = 2^1330 (bracket from 2663 bits; its ends as literals from `PowDiffFarBracket`).
It imports `PowDiffFarRhin1` only to run after it, so `lake build` never runs two stretches
side by side.
-/

namespace PowDiff

open AcceleratedCollatz

set_option exponentiation.threshold 2000 in
/-- Stretch 2 of the upper walk to 10^200, computed by the kernel. -/
theorem rhinStretch_200_2 :
    walkTo (rhinOKAt (2 ^ 1330) (log2Hi 3 2663 1330))
      (2 ^ 1330) (log2Lo 3 2663 1330) (log2Hi 3 2663 1330)
      farNode200_2 1600 farNode200_1 = true := by
  rw [farLo200_eq, farHi200_eq]
  decide +kernel

end PowDiff
